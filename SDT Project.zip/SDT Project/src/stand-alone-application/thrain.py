# thrain.py
# Python 3 compatible Thrain glue: encryption and decryption wrappers
# Uses DH.generate_secret(priv_int, pub_int) and ENCDEC.AESCipher

import os
import binascii
import hashlib
import platform
import subprocess

import ENCDEC
import DH  # your DH module (must provide generate_secret)

# Helper: convert user-supplied key (digits or text) into an integer suitable for DH
def _key_to_int(key_str: str) -> int:
    """
    If key_str is numeric, return int(key_str).
    Otherwise return a stable large int derived from SHA-256(key_str).
    """
    if key_str is None:
        raise ValueError("Key is None")
    s = str(key_str).strip()
    if s == "":
        raise ValueError("Key is empty")
    if s.isdecimal():
        return int(s)
    # Non-numeric: hash and convert to int
    digest = hashlib.sha256(s.encode("utf-8")).digest()
    return int.from_bytes(digest, "big")

# Helper: open folder in OS-specific way
def _open_folder(path: str):
    try:
        if platform.system() == "Windows":
            os.startfile(path)
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", path])
        else:  # Linux and others
            subprocess.Popen(["xdg-open", path])
    except Exception:
        # ignore errors opening folder; caller doesn't need to crash
        pass

# Helper: derive a string key from shared_secret (int)
def _derive_key_from_secret(shared_secret, hex_length=32):
    # Ensure shared_secret is integer
    if isinstance(shared_secret, str):
        try:
            shared_secret = int(shared_secret)
        except ValueError:
            # If it's a hex string like '0xabc123', handle that
            shared_secret = int(shared_secret, 16)
    
    # Convert to hex string
    hex_str = format(shared_secret, "x")  # hex without 0x
    if len(hex_str) < hex_length:
        hex_str = hex_str.zfill(hex_length)  # pad with leading zeros
    elif len(hex_str) > hex_length:
        hex_str = hex_str[:hex_length]  # trim if too long

    return hex_str

# ENCRYPT
def encrypt(filename: str, directory: str, public_key: str, private_key: str) -> str:
    """
    Encrypt a text file `filename` and save output to `directory`.
    public_key / private_key may be numeric strings or arbitrary text.
    Returns output filename (full path) on success.
    Raises exceptions on error.
    """

    # Validate paths
    if not os.path.isfile(filename):
        raise FileNotFoundError(f"Input file not found: {filename}")
    if not os.path.isdir(directory):
        # if user passed a file path (not folder), allow parent dir
        parent = os.path.dirname(directory)
        if parent and os.path.isdir(parent):
            directory = parent
        else:
            raise NotADirectoryError(f"Save directory not found: {directory}")

    # Convert keys to ints for DH
    priv_int = _key_to_int(private_key)
    pub_int = _key_to_int(public_key)

    # Compute shared secret using your DH implementation
    shared_secret = DH.generate_secret(priv_int, pub_int)
    # Derive string key (hex) to give to ENCDEC (which will hash it)
    key_str = _derive_key_from_secret(shared_secret, hex_length=32)

    # Read input file (text)
    with open(filename, "r", encoding="utf-8") as f:
        plaintext = f.read()

    # Encrypt using ENCDEC.AESCipher (expects a string key)
    cipher = ENCDEC.AESCipher(key_str)
    ciphertext = cipher.encrypt(plaintext)

    # Choose output filename: use key suffix to keep original behavior, but safe
    safe_suffix = key_str[16:] if len(key_str) >= 16 else key_str
    base_outname = os.path.basename(filename)
    out_filename = os.path.join(directory, f"{safe_suffix}_{base_outname}.enc.txt")

    # Write ciphertext
    with open(out_filename, "w", encoding="utf-8") as out_f:
        out_f.write(ciphertext)

    # Optionally remove original file (original code did os.remove(filename))
    # Keep original behaviour: remove input file after successful encryption
    try:
        os.remove(filename)
    except Exception:
        # If remove fails, do not crash; continue
        pass

    # Open folder to show the file
    _open_folder(directory)

    return out_filename

# DECRYPT
def decrypt(filename: str, directory: str, public_key: str, private_key: str) -> str:
    """
    Decrypt a ciphertext file `filename` and write a decoded file to `directory`.
    public_key / private_key may be numeric strings or arbitrary text.
    Returns output filename (full path) on success.
    Raises exceptions on error.
    """

    if not os.path.isfile(filename):
        raise FileNotFoundError(f"Encrypted file not found: {filename}")
    if not os.path.isdir(directory):
        parent = os.path.dirname(directory)
        if parent and os.path.isdir(parent):
            directory = parent
        else:
            raise NotADirectoryError(f"Save directory not found: {directory}")

    # Convert keys to ints for DH
    priv_int = _key_to_int(private_key)
    pub_int = _key_to_int(public_key)

    # Compute shared secret
    shared_secret = DH.generate_secret(priv_int, pub_int)
    key_str = _derive_key_from_secret(shared_secret, hex_length=32)

    # Read ciphertext
    with open(filename, "r", encoding="utf-8") as f:
        ciphertext = f.read()

    # Decrypt
    cipher = ENCDEC.AESCipher(key_str)
    plaintext = cipher.decrypt(ciphertext)

    # Write decoded file (use a meaningful name)
    base_outname = "DecodedFile.txt"
    out_filename = os.path.join(directory, base_outname)
    with open(out_filename, "w", encoding="utf-8") as out_f:
        out_f.write(plaintext)

    # Optionally remove encrypted file (original code did)
    try:
        os.remove(filename)
    except Exception:
        pass

    _open_folder(directory)
    return out_filename
