import tkinter as tk
from tkinter import *
from tkinter import filedialog as tkFileDialog
from tkinter import messagebox as tkMessageBox
import webbrowser
import thrain

'''
-----------------------------------------------------------------
OPEN FILE AND DIRECTORY
-----------------------------------------------------------------
'''
def openfileEnc():
    filename = tkFileDialog.askopenfilename(
        initialdir="/home/parth/Desktop",
        title="Select file",
        filetypes=(("text files", "*.txt"), ("all files", "*.*"))
    )
    fileToEncrptyEntryUpdate(filename)

def opendirectoryEnc():
    directory = tkFileDialog.askdirectory(
        initialdir="/home/parth/Desktop", title="Select directory"
    )
    destinationFolderEncEntryUpdate(directory)

def openfileDec():
    filename = tkFileDialog.askopenfilename(
        initialdir="/home/parth/Desktop",
        title="Select file",
        filetypes=(("text files", "*.txt"), ("all files", "*.*"))
    )
    fileToDecryptEntryUpdate(filename)

def opendirectoryDec():
    directory = tkFileDialog.askdirectory(
        initialdir="/home/parth/Desktop", title="Select directory"
    )
    destinationFolderDecEntryUpdate(directory)

'''
-----------------------------------------------------------------
OPEN SOCIAL LINKS
-----------------------------------------------------------------
'''
def sendfilepage():
    webbrowser.open_new(r"https://send-anywhere.com/")

def recievefilepage():
    webbrowser.open_new(r"https://send-anywhere.com/")

def opengithub(event=None):
    webbrowser.open_new(r"https://github.com/Gunaseelan5863/Secure-Data-Transmission-In-Internet")

def openhardiklinkedin(event=None):
    webbrowser.open_new(r"https://www.linkedin.com/in/gunaseelan-b-483802279?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app")

'''
-----------------------------------------------------------------
UPDATE ENTRY LABELS
-----------------------------------------------------------------
'''
def fileToEncrptyEntryUpdate(filename):
    inputEncFileEntry.delete(0, END)
    inputEncFileEntry.insert(0, filename)

def destinationFolderEncEntryUpdate(directory):
    inputEncDirEntry.delete(0, END)
    inputEncDirEntry.insert(0, directory)

def fileToDecryptEntryUpdate(filename):
    outputDecFileEntry.delete(0, END)
    outputDecFileEntry.insert(0, filename)

def destinationFolderDecEntryUpdate(directory):
    outputDecDirEntry.delete(0, END)
    outputDecDirEntry.insert(0, directory)

'''
-----------------------------------------------------------------
ENCRYPT-DECRYPT TRIGGER BUTTON
-----------------------------------------------------------------
'''
def encryptor():
    EncryptBTN.config(state="disabled")
    public_key = publicKeyOfRecieverEntry.get()
    private_key = privateKeyOfSenderEntry.get()
    directory = inputEncDirEntry.get()
    filename = inputEncFileEntry.get()
    thrain.encrypt(filename, directory, public_key, private_key)
    EncryptBTN.config(state="normal")
    tkMessageBox.showinfo("Success", "File encrypted successfully!")

def decryptor():
    DecryptBTN.config(state="disabled")
    public_key = publicKeyOfSenderEntry.get()
    private_key = privateKeyOfRecieverEntry.get()
    directory = outputDecDirEntry.get()
    filename = outputDecFileEntry.get()
    thrain.decrypt(filename, directory, public_key, private_key)
    DecryptBTN.config(state="normal")
    tkMessageBox.showinfo("Success", "File decrypted successfully!")

'''
-----------------------------------------------------------------
MAIN FUNCTION
-----------------------------------------------------------------
'''
def main():
    global form
    form = tk.Tk()
    form.wm_title('Secure File Transfer')

    '''
    -------------------------------------------------------------
    Form Label Configuration
    -------------------------------------------------------------
    '''
    EncryptStep = LabelFrame(form, text=" 1. File Encryption: ")
    EncryptStep.grid(row=0, columnspan=7, sticky='W', padx=5, pady=5, ipadx=5, ipady=5)

    DecryptStep = LabelFrame(form, text=" 2. File Decryption: ")
    DecryptStep.grid(row=2, columnspan=7, sticky='W', padx=5, pady=5, ipadx=5, ipady=5)

    Aboutus = LabelFrame(form, text=" About ")
    Aboutus.grid(row=0, column=9, columnspan=2, rowspan=8, sticky='NS', padx=5, pady=5)

    '''
    -------------------------------------------------------------
    Menu Bar
    -------------------------------------------------------------
    '''
    menu = Menu(form)
    form.config(menu=menu)

    menufile = Menu(menu, tearoff=0)
    menufile.add_command(label='Send file', command=sendfilepage)
    menufile.add_command(label='Receive file', command=recievefilepage)
    menufile.add_command(label='Exit', command=form.quit)
    menu.add_cascade(label='Menu', menu=menufile)

    '''
    -------------------------------------------------------------
    ENCRYPT-SECTION
    -------------------------------------------------------------
    '''
    global inputEncFileEntry, inputEncDirEntry
    global publicKeyOfRecieverEntry, privateKeyOfSenderEntry
    global EncryptBTN

    Label(EncryptStep, text="Select the File:").grid(row=0, column=0, sticky='E', padx=5, pady=2)
    inputEncFileEntry = Entry(EncryptStep)
    inputEncFileEntry.grid(row=0, column=1, columnspan=7, sticky="WE", pady=3)
    Button(EncryptStep, text="Browse ...", command=openfileEnc).grid(row=0, column=8, sticky='W', padx=5, pady=2)

    Label(EncryptStep, text="Save File to:").grid(row=1, column=0, sticky='E', padx=5, pady=2)
    inputEncDirEntry = Entry(EncryptStep)
    inputEncDirEntry.grid(row=1, column=1, columnspan=7, sticky="WE", pady=2)
    Button(EncryptStep, text="Browse ...", command=opendirectoryEnc).grid(row=1, column=8, sticky='W', padx=5, pady=2)

    Label(EncryptStep, text="Public-Key of receiver:").grid(row=2, column=0, sticky='E', padx=5, pady=2)
    publicKeyOfRecieverEntry = Entry(EncryptStep)
    publicKeyOfRecieverEntry.grid(row=2, column=1, sticky='E', pady=2)

    Label(EncryptStep, text="Private-Key of sender:").grid(row=2, column=5, padx=5, pady=2)
    privateKeyOfSenderEntry = Entry(EncryptStep)
    privateKeyOfSenderEntry.grid(row=2, column=7, pady=2)

    EncryptBTN = tk.Button(EncryptStep, text="Encrypt", command=encryptor)
    EncryptBTN.grid(row=2, column=8, sticky='W', padx=5, pady=2)

    '''
    -------------------------------------------------------------
    DECRYPT-SECTION
    -------------------------------------------------------------
    '''
    global outputDecFileEntry, outputDecDirEntry
    global publicKeyOfSenderEntry, privateKeyOfRecieverEntry
    global DecryptBTN

    Label(DecryptStep, text="Select the File:").grid(row=0, column=0, sticky='E', padx=5, pady=2)
    outputDecFileEntry = Entry(DecryptStep)
    outputDecFileEntry.grid(row=0, column=1, columnspan=7, sticky="WE", pady=3)
    Button(DecryptStep, text="Browse ...", command=openfileDec).grid(row=0, column=8, sticky='W', padx=5, pady=2)

    Label(DecryptStep, text="Save File to:").grid(row=1, column=0, sticky='E', padx=5, pady=2)
    outputDecDirEntry = Entry(DecryptStep)
    outputDecDirEntry.grid(row=1, column=1, columnspan=7, sticky="WE", pady=2)
    Button(DecryptStep, text="Browse ...", command=opendirectoryDec).grid(row=1, column=8, sticky='W', padx=5, pady=2)

    Label(DecryptStep, text="Public-Key of sender:").grid(row=2, column=0, sticky='E', padx=5, pady=2)
    publicKeyOfSenderEntry = Entry(DecryptStep)
    publicKeyOfSenderEntry.grid(row=2, column=1, sticky='E', pady=2)

    Label(DecryptStep, text="Private-Key of receiver:").grid(row=2, column=5, padx=5, pady=2)
    privateKeyOfRecieverEntry = Entry(DecryptStep)
    privateKeyOfRecieverEntry.grid(row=2, column=7, pady=2)

    DecryptBTN = tk.Button(DecryptStep, text="Decrypt", command=decryptor)
    DecryptBTN.grid(row=2, column=8, sticky='W', padx=5, pady=2)

    '''
    -------------------------------------------------------------
    ABOUT US SECTION
    -------------------------------------------------------------
    '''
    Label(Aboutus, text="\nGuna - A secure file transfer system").grid(row=0)
    Label(Aboutus, text="\nGuna enables its users to securely\ntransfer files in 'txt' format without\nany third-party eavesdropping\n").grid(row=1)
    githublink = Label(Aboutus, text="Know More", fg="blue", cursor="hand2")
    githublink.bind("<Button-1>", opengithub)
    githublink.grid(row=2)
    Label(Aboutus, text="\n\n\n\n").grid(row=3)
    Label(Aboutus, text="Done by: ").grid(row=4, sticky='S')
    hardiksocial = Label(Aboutus, text="GUNASEELAN B", fg="blue", cursor="hand2")
    hardiksocial.bind("<Button-1>", openhardiklinkedin)
    hardiksocial.grid(row=5, sticky='SW', padx=8)
    
    form.mainloop()


if __name__ == "__main__":
    main()
