long = int
import binascii
import os
import base64
import hashlib
from Crypto.Cipher import AES
from secretsharing import PlaintextToHexSecretSharer, SecretSharer


# AES block size
BLOCK_SIZE = 16

# Padding and unpadding for AES
def pad(data: bytes) -> bytes:
    pad_len = BLOCK_SIZE - len(data) % BLOCK_SIZE
    return data + bytes([pad_len]) * pad_len

def unpad(data: bytes) -> bytes:
    return data[:-data[-1]]

# ==============================
# SHAMIR’S SECRET SHARING
# ==============================
def shamirs_split(file_object):
    """
    Split the file content into shares using Shamir's Secret Sharing algorithm.
    Returns a tuple of (hexcode_list, extra_part).
    """
    text = file_object.read()
    if isinstance(text, bytes):
        text = text.decode("utf-8")

    # Split secret into 2 parts, both required to recover
    list_hex = PlaintextToHexSecretSharer.split_secret(text, 2, 2)

    # Further split first part
    hexcode = SecretSharer.split_secret(list_hex[0][2:], 2, 2)
    return hexcode, list_hex[1]

def shamirs_join(list_hex, extra_str):
    """
    Join the Shamir secret parts to recover the original text.
    """
    msg_alpha = SecretSharer.recover_secret(list_hex[:2])
    msg_alpha = "1-" + msg_alpha
    temp = [msg_alpha, extra_str]
    text = PlaintextToHexSecretSharer.recover_secret(temp[:2])
    return text

# ==============================
# AES ENCRYPTION / DECRYPTION
# ==============================
def iv():
    """Generate a static 16-byte initialization vector."""
    return b'\x00' * 16

class AESCipher:
    """
    AES Cipher class for encryption and decryption using CBC mode.
    """

    def __init__(self, key: str):
        # Create a secure AES-256 key
        if isinstance(key, str):
            key = key.encode("utf-8")
        self.key = hashlib.sha256(key).digest()

    def encrypt(self, message: str) -> str:
        """Encrypt a plaintext string and return Base64 string."""
        if isinstance(message, str):
            message = message.encode("utf-8")

        raw = pad(message)
        cipher = AES.new(self.key, AES.MODE_CBC, iv())
        enc = cipher.encrypt(raw)
        return base64.b64encode(enc).decode("utf-8")

    def decrypt(self, enc: str) -> str:
        """Decrypt a Base64-encoded string."""
        enc_bytes = base64.b64decode(enc)
        cipher = AES.new(self.key, AES.MODE_CBC, iv())
        dec = cipher.decrypt(enc_bytes)
        return unpad(dec).decode("utf-8")
